import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

export default function App() {
  const [task, setTask] = useState('');
  const [taskList, setTaskList] = useState([
    { id: 1, name: 'Học bài', completed: false },
    { id: 2, name: 'Ăn sáng', completed: false },
    { id: 3, name: 'Đọc sách', completed: false },
  ]);
  const [filteredTaskList, setFilteredTaskList] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');

  const addTask = () => {
    if (task.trim() !== '') {
      const newTask = {
        id: new Date().getTime(),
        name: task,
        completed: false
      };
      setTaskList([...taskList, newTask]);
      setTask('');
    }
  };

  const toggleTask = id => {
    const updatedTaskList = taskList.map(task => {
      if (task.id === id) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    setTaskList(updatedTaskList);
  };

  const deleteTask = id => {
    const updatedTaskList = taskList.filter(task => task.id !== id);
    setTaskList(updatedTaskList);
  };

  const searchTask = keyword => {
    setSearchKeyword(keyword);
    const filteredTasks = taskList.filter(task =>
      task.name.toLowerCase().includes(keyword.toLowerCase())
    );
    setFilteredTaskList(filteredTasks);
  };

  return (
    <View style={styles.container}>
      <View style={styles.innerContainer}>
        <Text style={styles.title}>TODO LIST</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Thêm nhiệm vụ"
            value={task}
            onChangeText={setTask}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <AntDesign name="plus" size={24} color="white" />
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.searchInput}
          placeholder="Tìm kiếm nhiệm vụ"
          value={searchKeyword}
          onChangeText={searchTask}
        />
        <FlatList
          data={searchKeyword ? filteredTaskList : taskList}
          keyExtractor={item => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.taskContainer}>
              <TouchableOpacity style={styles.checkbox} onPress={() => toggleTask(item.id)}>
                {item.completed && <AntDesign name="check" size={18} color="black" />}
              </TouchableOpacity>
              <Text
                style={[styles.task, item.completed && styles.completedTask]}
              >
                {item.name}
              </Text>
              <TouchableOpacity style={styles.deleteButton} onPress={() => deleteTask(item.id)}>
                <AntDesign name="delete" size={18} color="white" />
              </TouchableOpacity>
            </View>
          )}
        />
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fedaff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerContainer: {
    width: '80%',
  },
  title: {
    color: 'blue',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    borderWidth: 2,
    borderColor: '#0a98ed',
    borderRadius: 4,
    marginRight: 10,
    paddingHorizontal: 10,
  },
  addButton: {
    backgroundColor: '#68e2f1',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  searchInput: {
    borderWidth: 2,
    borderColor: '#0a98ed',
    borderRadius: 4,
    marginBottom: 30,
    paddingHorizontal: 15,
  },
  taskContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkbox: {
    borderWidth: 1,
    borderColor: 'green',
    borderRadius: 4,
    padding: 5,
    marginRight: 10,
  },
  task: {
    flex: 1,
    fontSize: 16,
  },
  completedTask: {
    textDecorationLine: 'line-through',
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
  },
});
